const $ = id => document.getElementById(id);
const API = location.protocol === "file:" ? "http://127.0.0.1:5000" : "";
const COLORS = {safe: "#0b7a43", suspicious: "#d98200", phishing: "#c62828"};
const LABEL = {safe: "✅ Looks safe", suspicious: "⚠️ Suspicious", phishing: "🚨 Likely phishing"};
const esc = s => String(s).replace(/[&<>"]/g, c => ({"&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"}[c]));
const el = (t, c, x) => Object.assign(document.createElement(t), {className: c || "", textContent: x ?? ""});
async function api(path, opts) {
  const r = await fetch(API + path, opts), d = await r.json();
  if (!r.ok) throw new Error(d.error || "Request failed");
  return d;
}

/* ---------- charts (plain SVG, work offline) ---------- */
function hbar(box, rows, max, unit) {
  const W = 640, L = 250, B = W - L - 60, h = 32;
  box.innerHTML = `<svg viewBox="0 0 ${W} ${rows.length * h + 6}" role="img">` + rows.map((r, i) => {
    const y = i * h + 3, w = Math.max(2, r.value / max * B);
    return `<text x="${L - 8}" y="${y + 19}" text-anchor="end">${esc(r.label)}</text><rect x="${L}" y="${y + 4}" width="${w}" height="20" rx="4" fill="${r.color}"/><text x="${L + w + 6}" y="${y + 19}">${r.value}${unit}</text>`;
  }).join("") + "</svg>";
}
function grouped(box, rows) {
  const W = 640, L = 250, B = W - L - 60, h = 44;
  box.innerHTML = `<svg viewBox="0 0 ${W} ${rows.length * h + 6}" role="img">` + rows.map((r, i) => {
    const y = i * h + 3, a = Math.max(2, r.a / 100 * B), b = Math.max(2, r.b / 100 * B);
    return `<text x="${L - 8}" y="${y + 22}" text-anchor="end">${esc(r.label)}</text>` +
      `<rect x="${L}" y="${y + 3}" width="${a}" height="14" rx="3" fill="#c62828"/><text x="${L + a + 6}" y="${y + 15}">${r.a}%</text>` +
      `<rect x="${L}" y="${y + 21}" width="${b}" height="14" rx="3" fill="#0b7a43"/><text x="${L + b + 6}" y="${y + 33}">${r.b}%</text>`;
  }).join("") + "</svg>";
}
function donut(box, parts) {
  const C = 2 * Math.PI * 60, tot = parts.reduce((a, p) => a + p.value, 0); let off = 0;
  const arcs = parts.filter(p => p.value).map(p => {
    const len = p.value / tot * C, s = `<circle cx="80" cy="80" r="60" fill="none" stroke="${p.color}" stroke-width="22" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}" transform="rotate(-90 80 80)"/>`;
    off += len; return s;
  }).join("");
  box.innerHTML = `<svg viewBox="0 0 160 160" class="donut" role="img"><circle cx="80" cy="80" r="60" fill="none" stroke="#8883" stroke-width="22"/>${arcs}<text x="80" y="88" text-anchor="middle" class="dt">${tot}</text></svg>` +
    `<div class="lg">${parts.map(p => `<span><i style="background:${p.color}"></i>${esc(p.label)}: ${p.value}</span>`).join("")}</div>`;
}

/* ---------- landing slideshow ---------- */
const SLIDES = [
 ["Welcome to PhishGuard Nigeria", "Check any link for fake bank, company, government and school websites before you trust it."],
 ["Phishing hooks people, not computers", "Fake messages copy trusted names to steal your PIN, OTP, BVN and passwords."],
 ["Learn from the data", "See which website traits most often separate phishing from legitimate sites."]];
let cur = 0, timer;
function slide(i) {
  cur = i;
  document.querySelectorAll(".slide").forEach((s, k) => s.classList.toggle("on", k === i));
  document.querySelectorAll("#dots i").forEach((d, k) => d.classList.toggle("on", k === i));
  $("sl-title").textContent = SLIDES[i][0]; $("sl-text").textContent = SLIDES[i][1];
}
function startSlides() {
  $("dots").replaceChildren(...SLIDES.map((_, i) => Object.assign(el("i"), {onclick: () => { slide(i); startSlides(); }})));
  clearInterval(timer); slide(cur); timer = setInterval(() => slide((cur + 1) % SLIDES.length), 6000);
}

/* ---------- navigation with loading icon ---------- */
function tab(name) {
  if (name === "home") { $("app").hidden = true; $("landing").hidden = false; scrollTo(0, 0); return; }
  loadStats(); loadHistory(); scrollTo(0, 0);
}
function enter(name) {
  $("loader").hidden = false;
  setTimeout(() => { $("loader").hidden = true; $("landing").hidden = true; $("app").hidden = false; tab(name); }, 1400);
}
document.querySelectorAll("[data-go]").forEach(b => b.onclick = () => b.dataset.go === "scan" ? enter("scan") : $(b.dataset.go).scrollIntoView());
document.querySelectorAll("[data-jump]").forEach(b => b.onclick = () => $(b.dataset.jump).scrollIntoView({behavior: "smooth"}));
document.querySelectorAll("[data-tab]").forEach(b => b.onclick = () => tab(b.dataset.tab));

/* ---------- scan ---------- */
async function scan() {
  $("err").textContent = "";
  try {
    const r = await api("/api/scan", {method: "POST", headers: {"Content-Type": "application/json"}, body: JSON.stringify({url: $("url").value})});
    $("result").hidden = false; $("bar").style.width = r.score + "%"; $("bar").style.background = COLORS[r.verdict];
    $("verdict").textContent = `${LABEL[r.verdict]} (risk ${r.score}/100)`;
    $("brand").textContent = r.brand ? "Brand involved: " + r.brand : "";
    $("ml").textContent = r.ml_prob == null ? "" : `🌲 Random Forest model: ${r.ml_prob}% chance this is phishing`;
    $("reasons").replaceChildren(...r.reasons.map(t => el("li", "", t)));
    loadHistory(); loadStats();
  } catch (e) { $("err").textContent = e.message === "Failed to fetch" ? "Cannot reach PhishGuard. Start it with run.bat." : e.message; $("result").hidden = true; }
}
async function loadStats() {
  try { const s = await api("/api/stats");
    donut($("ch-scans"), [{label: "Safe", value: s.safe, color: COLORS.safe}, {label: "Suspicious", value: s.suspicious, color: COLORS.suspicious}, {label: "Phishing", value: s.phishing, color: COLORS.phishing}]);
  } catch {}
}
async function loadHistory() {
  try {
    const h = await api("/api/history");
    $("history").replaceChildren(...h.map(x => { const li = el("li"); li.append(el("span", "tag t-" + x.verdict, x.verdict), x.url); return li; }));
    if (!h.length) $("history").textContent = "No scans yet.";
  } catch {}
}

/* ---------- news ---------- */
async function loadNews() {
  try {
    const n = await api("/api/news");
    $("news-count").textContent = n.length + " articles";
    $("newsl").replaceChildren(...n.map(x => {
      const li = el("li"), a = el("a", "", x.title);
      a.href = /^https?:/.test(x.link) ? x.link : "#"; a.target = "_blank"; a.rel = "noopener";
      li.append(el("span", "src", x.source || "News"), a, x.date ? " · " + x.date : ""); return li; }));
  } catch { $("newsl").textContent = "News unavailable. Start PhishGuard with run.bat."; }
}

/* ---------- analysis ---------- */
let analysis;
async function loadAnalysis() {
  try {
    const a = analysis = await api("/api/analysis");
    $("a-sum").textContent = `Mined ${a.total} labelled URLs: ${a.phishing} phishing and ${a.legit} legitimate.`;
    $("a-note").textContent = a.note;
    $("a-find").replaceChildren(...a.features.slice(0, 3).map(f => el("li", "", `${f.name}: found in ${f.phish_pct}% of phishing URLs but only ${f.legit_pct}% of legitimate ones.`)));
    donut($("ch-balance"), [{label: "Phishing", value: a.phishing, color: COLORS.phishing}, {label: "Legitimate", value: a.legit, color: COLORS.safe}]);
    const top = a.features.slice(0, 8);
    hbar($("ch-gain"), top.map(f => ({label: f.name, value: f.gain, color: "#0b7a43"})), Math.max(...top.map(f => f.gain), 0.01), "");
    grouped($("ch-prev"), a.features.map(f => ({label: f.name, a: f.phish_pct, b: f.legit_pct})));
    $("a-pairs").replaceChildren(...a.pairs.map(p => { const tr = el("tr"); [p.rule, p.support + "%", p.confidence + "%", p.lift].forEach(v => tr.append(el("td", "", v))); return tr; }));
    $("teaser").replaceChildren(...[[a.total, "URLs analysed"], [a.features[0].phish_pct + "%", "of phishing URLs: " + a.features[0].name.toLowerCase()], [a.features[1].phish_pct + "%", "of phishing URLs: " + a.features[1].name.toLowerCase()]]
      .map(([b, t]) => { const d = el("div"); d.append(el("b", "", b), t); return d; }));
  } catch { $("a-sum").textContent = "Analysis unavailable. Start PhishGuard with run.bat."; }
}

async function loadModel() {
  try {
    const m = await api("/api/model");
    $("rf-sum").textContent = `${m.trees} decision trees trained on ${m.train_size} URLs and tested on ${m.test_size} unseen URLs. ${m.note}`;
    const cards = [[m.accuracy + "%", "Accuracy"], [m.precision + "%", "Precision"], [m.recall + "%", "Recall"], [m.f1 + "%", "F1-score"]];
    if (m.cv_accuracy != null) cards.push([m.cv_accuracy + "%", m.cv_folds + "-fold cross-validation"]);
    $("rf-cards").replaceChildren(...cards.map(([v, t]) => { const d = el("div"); d.append(el("b", "", v), t); return d; }));
    const c = m.confusion;
    $("rf-cm").innerHTML = `<table class="cm"><tr><th></th><th>Predicted phishing</th><th>Predicted legitimate</th></tr><tr><th>Actually phishing</th><td class="ok">${c.tp}</td><td class="bad">${c.fn}</td></tr><tr><th>Actually legitimate</th><td class="bad">${c.fp}</td><td class="ok">${c.tn}</td></tr></table>`;
    const imp = m.importance.slice(0, 8);
    hbar($("ch-imp"), imp.map(f => ({label: f.name, value: f.value, color: "#0b7a43"})), Math.max(...imp.map(f => f.value), 1), "%");
  } catch { $("rf-sum").textContent = "Model unavailable. Start PhishGuard with run.bat."; }
}

$("go").onclick = scan;
$("url").addEventListener("keydown", e => e.key === "Enter" && scan());
startSlides(); loadAnalysis(); loadModel(); loadNews(); setInterval(loadNews, 600000);
