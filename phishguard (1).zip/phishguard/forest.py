"""Random Forest classifier written in pure Python (no libraries), trained on data/dataset.csv.
Each URL becomes 11 yes/no features (the same ones used in mining.py)."""
import csv, math, os, random, threading
import mining

N_TREES, MAX_DEPTH, MIN_LEAF, SEED = 60, 8, 2, 42
_lock, _state = threading.Lock(), {}

def vec(url):
    u = url.strip().lower(); h = mining.host_of(u)
    return [1 if fn(u, h) else 0 for fn in mining.FEATURES.values()]

def gini(p): return 2 * p * (1 - p)

def build(X, y, idx, depth, rng, imp, m):
    n = len(idx); pos = sum(y[i] for i in idx); leaf = {"p": pos / n}
    if depth >= MAX_DEPTH or n < 2 * MIN_LEAF or pos in (0, n): return leaf
    best, g0 = None, gini(pos / n)
    for f in rng.sample(range(len(X[0])), m):          # random subset of features at every split
        r = [i for i in idx if X[i][f]]; nr = len(r); nl = n - nr
        if nr < MIN_LEAF or nl < MIN_LEAF: continue
        pr = sum(y[i] for i in r)
        gain = g0 - (nl * gini((pos - pr) / nl) + nr * gini(pr / nr)) / n
        if best is None or gain > best[0]: best = (gain, f, r)
    if not best or best[0] <= 1e-9: return leaf
    gain, f, r = best; rs = set(r); imp[f] += n * gain
    return {"f": f, "l": build(X, y, [i for i in idx if i not in rs], depth + 1, rng, imp, m),
            "r": build(X, y, r, depth + 1, rng, imp, m)}

def walk(t, x):
    while "f" in t: t = t["r"] if x[t["f"]] else t["l"]
    return t["p"]

def proba(trees, x): return sum(walk(t, x) for t in trees) / len(trees)

def train(X, y, idx, rng):
    nf = len(X[0]); m = max(1, int(math.sqrt(nf))); imp = [0.0] * nf; size = min(len(idx), 5000)
    return [build(X, y, [rng.choice(idx) for _ in range(size)], 0, rng, imp, m) for _ in range(N_TREES)], imp

def score(trees, X, y, idx):
    tp = fp = tn = fn = 0
    for i in idx:
        p = proba(trees, X[i]) >= 0.5
        if p and y[i]: tp += 1
        elif p: fp += 1
        elif y[i]: fn += 1
        else: tn += 1
    return tp, fp, tn, fn

def folds(y, k, rng):
    out = [[] for _ in range(k)]
    for cls in (0, 1):
        ids = [i for i, v in enumerate(y) if v == cls]; rng.shuffle(ids)
        for j, i in enumerate(ids): out[j % k].append(i)
    return out

def pct(a, b): return round(100 * a / b, 1) if b else 0.0

def _fit(key):
    with open(mining.DATA, encoding="utf-8") as f:
        rows = [(r["url"], r["label"].strip() == "phishing") for r in csv.DictReader(f)]
    X, y = [vec(u) for u, _ in rows], [int(v) for _, v in rows]
    if len(set(y)) < 2 or len(y) < 20: raise ValueError("Dataset needs both phishing and legitimate URLs.")
    rng = random.Random(SEED); fs = folds(y, 10, rng)
    test = [i for f in fs[:3] for i in f]; tr = [i for f in fs[3:] for i in f]
    trees, imp = train(X, y, tr, rng); tp, fp, tn, fn = score(trees, X, y, test)
    p, r = pct(tp, tp + fp), pct(tp, tp + fn)
    cv = None
    if len(y) <= 5000:                                  # k-fold cross-validation
        k5, accs = folds(y, 5, rng), []
        for j in range(5):
            t5, _ = train(X, y, [i for q in range(5) if q != j for i in k5[q]], rng)
            a, b, c, d = score(t5, X, y, k5[j]); accs.append(pct(a + c, a + b + c + d))
        cv = round(sum(accs) / 5, 1)
    tot = sum(imp) or 1
    _state.update(key=key, trees=trees, res={
        "trees": N_TREES, "train_size": len(tr), "test_size": len(test),
        "accuracy": pct(tp + tn, len(test)), "precision": p, "recall": r,
        "f1": round(2 * p * r / (p + r), 1) if p + r else 0.0,
        "confusion": {"tp": tp, "fp": fp, "tn": tn, "fn": fn}, "cv_accuracy": cv, "cv_folds": 5,
        "importance": sorted(({"name": n, "value": round(100 * v / tot, 1)} for n, v in zip(mining.FEATURES, imp)),
                             key=lambda d: -d["value"]),
        "note": "Demo dataset: these scores describe this small sample, not real-world performance." if len(y) < 1000 else ""})

def evaluate():
    key = os.path.getmtime(mining.DATA)
    with _lock:
        if _state.get("key") != key: _fit(key)
        return _state["res"]

def predict(url):
    evaluate()
    with _lock:
        return round(100 * proba(_state["trees"], vec(url)), 1)
